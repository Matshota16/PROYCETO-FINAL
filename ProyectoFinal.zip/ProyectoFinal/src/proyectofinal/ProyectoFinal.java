
package proyectofinal;
import java.util.Scanner;
public class ProyectoFinal {

    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
       
       registroYBienvenida();

    }
    public static void registroYBienvenida() {
     
        System.out.print("HOlA, bienvenido a almacenes don baraton, ingrese su edad:");
        int edad = scanner.nextInt();
       
        boolean esPrimo = true;        
        if (edad >= 18) {
            pruebas();
            
        }else if(edad < 18){
            CalcularCuantosAñosFaltan();
        }
        
            }
            
        
                  
       public static void menuPrincipal() {
        
           
           System.out.print("Selecciona que requiere comprar:\n\n"
                + "1. laptops\n"
                + "2. consolas\n"
                + "3. dispositivos moviles\n"
                + "4. computadoras de escritorio\n"
                + "5. accesorios\n\n"
                + "Selecione una opcion: ");
        int opcionDeCompra = scanner.nextInt();
        
        switch(opcionDeCompra) {
            case 1:
                
                tipoDeLaptops();
                
                break;
                
            case 2:
                tipoDeConsolas();
                break;
                
            case 3:
                dispositivosMoviles();
                break;
                
            case 4:
                compusDeEscritorio();
            break;
            
            case 5:
                accesorios();
                break;
            default:
                System.out.println("Seleccione una opcion valida");
        }
        
    }
    
       
    public static void tipoDeLaptops() {
        System.out.print("solo se encontraron laptops de esta categoria\n\n"
                + "1. GAYmer\n"
                + "Elija una opcion: ");
        int marcaDeLaptops = scanner.nextInt();
        if (marcaDeLaptops == 1) {
            System.out.print("GAYmer\n"
                    + "Que modelo quieres comprar: \n"
                    + "a. MSI\n"
                    + "b. ACER\n"
                    + "c. ASUS\n"
                    + "d. LENOVO\n"
                    + "Elija: "
            );
        
            String opcionDeLaptops = scanner.next();
            
            if ((opcionDeLaptops.equals("a")) || (opcionDeLaptops.equals("A"))) {
                System.out.println("Disfrute de su dipositivo MSI :P");
            } else if ((opcionDeLaptops.equals("b")) || (opcionDeLaptops.equals("B"))) {
                System.out.println("Disfrute de su dipositivo ACER :P");
            } else if ((opcionDeLaptops.equals("c")) || (opcionDeLaptops.equals("C"))) {
                System.out.println("Disfrute de su dipositivo ASUS :P");
            } else if ((opcionDeLaptops.equals("d")) || (opcionDeLaptops.equals("D"))) {
                System.out.println("Disfrute de su dipositivo LENOVO :P");
            
            }
        }
    }
    public static void tipoDeConsolas() {
           System.out.print("solo se encuentran consolas de esta marca\n\n"
                + "1. Xbox\n"
                + "Elija una opcion: ");
        int consolasDisponibles = scanner.nextInt();
        if (consolasDisponibles == 1) {
            System.out.print("Xbox\n"
                    + "Que modelo quieres comprar: \n"
                    + "a. XBOX ONE\n"
                    + "b. XBOX ONE S\n"
                    + "c. XBOX SERIES X\n"
                    + "Elija: "
            );
        
            String opcionDeConsola = scanner.next();
            
            if ((opcionDeConsola.equals("a")) || (opcionDeConsola.equals("A"))) {
                System.out.println("Disfrute de su XBOX ONE :P");
            } else if ((opcionDeConsola.equals("b")) || (opcionDeConsola.equals("B"))) {
                System.out.println("Disfrute de su XBOX ONE S :P");
            } else if ((opcionDeConsola.equals("c")) || (opcionDeConsola.equals("C"))) {
                System.out.println("Disfrute de su XBOX SERIES X :P");
            
            }     
            
    }
    }
    public static void dispositivosMoviles() {
           System.out.print("solo se encuentran estos dispositivos\n\n"
                + "1. telefonos\n"
                + "Elija una opcion: ");
        int dispositivosMovilesDisponibles = scanner.nextInt();
        if (dispositivosMovilesDisponibles == 1) {
            System.out.print("telefonos\n"
                    + "De que modelo quiere comprar su telefono: \n"
                    + "a. xiaomi\n"
                    + "b. samsung\n"
                    + "c. motorola\n"
                    + "Elija: "
            );
        
            String opcionTelefonos = scanner.next();
            
            if ((opcionTelefonos.equals("a")) || (opcionTelefonos.equals("A"))) {
                System.out.println("Disfrute de su telefono marca xiaomi :P");
            } else if ((opcionTelefonos.equals("b")) || (opcionTelefonos.equals("B"))) {
                System.out.println("Disfrute de su telefono marca samsung :P");
            } else if ((opcionTelefonos.equals("c")) || (opcionTelefonos.equals("C"))) {
                System.out.println("Disfrute de su telefono marca motorola :P");
            
            }     
            
    }
    }  
    public static void compusDeEscritorio() {
           System.out.print("solo se encuentran PC de esta marca\n\n"
                + "1. xtreme\n"
                + "Elija una opcion: ");
        int ModeloXtreme = scanner.nextInt();
        if (ModeloXtreme == 1) {
            System.out.print("xtreme\n"
                    + "que modelo de pc gamer marca xtreme quiere adquirir: \n"
                    + "a. XTPCR58GBRENOIR\n"
                    + "b. XTBRR516GBRENOIRMR2\n"
                    + "c. XTPCI58GBHD630W\n"
                    + "Elija: "
            );
        
            String opcionDePc = scanner.next();
            
            if ((opcionDePc.equals("a")) || (opcionDePc.equals("A"))) {
                System.out.println("Disfrute de su pc gamer modelo XTPCR58GBRENOIR :P");
            } else if ((opcionDePc.equals("b")) || (opcionDePc.equals("B"))) {
                System.out.println("Disfrute de su pc gamer modelo XTBRR516GBRENOIRMR2 :P");
            } else if ((opcionDePc.equals("c")) || (opcionDePc.equals("C"))) {
                System.out.println("Disfrute de su pc gamer modelo XTPCI58GBHD630W  :P");
            
            }     
            
    }
    }  
    public static void accesorios() {
           System.out.print("solo se encontraron accesorios para\n\n"
                + "1. laptop\n"
                + "Elija una opcion: ");
        int tipoDeAccesorios = scanner.nextInt();
        if (tipoDeAccesorios == 1) {
            System.out.print("xtreme\n"
                    + "que accesorio para laptops desea comprar: \n"
                    + "a. mouse\n"
                    + "b. teclado\n"
                    + "c. memorias\n"
                    + "Elija: "
            );
        
            String opcionDeCompra = scanner.next();
            
            if ((opcionDeCompra.equals("a")) || (opcionDeCompra.equals("A"))) {
                System.out.println("Disfrute de su mouse :P");
            } else if ((opcionDeCompra.equals("b")) || (opcionDeCompra.equals("B"))) {
                System.out.println("Disfrute de su teclado :P");
            } else if ((opcionDeCompra.equals("c")) || (opcionDeCompra.equals("C"))) {
                System.out.println("Disfrute de su memoria :P");
            
            }     
            
    }
    }  

    public static void CalcularCuantosAñosFaltan() {
        Scanner obj=new Scanner (System.in);    
    System.out.println("ingrese nuevamente su edad para hacer un conteo de años: ");

    int b = obj.nextInt();
    
    boolean esPrimo = true;

     
    for (int n = b; n <= 18; n++) {
      esPrimo = true;
      for (int i = 1; i >= n; i++) {
        if (n % i == 0) {
          esPrimo = false;
 
        }
      }

      if (esPrimo) {
        System.out.println(n + " ");
        
        
      }
    }
    System.out.println("estas son las edades por las que debe pasar antes ");
    System.out.println("Seleccione si quiere regresar al lobby para hacer otro registro, o si quiere salir del sitio:\n\n"
                + "1. Regresar al lobby\n"
                + "2. salir del sitio\n"
                + "Selecione una opción: ");
       int opciones = scanner.nextInt();
       
       switch(opciones){
           case 1:
               registroYBienvenida();
               break;
           case 2:;
                System.out.println("asta luego, que tenga buen dia");
               break;
               
       }
                
    }
    public static void pruebas(){
    Scanner Reader = new Scanner(System.in);
        int contador;
        int fin;
        contador = 1;
        System.out.println("Por favor ahora ingrese la cantidad de veces que quiere que se ejecute el programa");
        fin = Reader.nextInt();
        while (contador <= fin){
        System.out.println("."+contador);
        contador++;
                  menuPrincipal();
                  
              }
    }
    }

   
